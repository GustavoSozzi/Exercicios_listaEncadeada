# Jogo-Da-Forca
 Jogo da forca feito em C utilizando arquivos, ponteiros, estruturas e listas encadeadas.
